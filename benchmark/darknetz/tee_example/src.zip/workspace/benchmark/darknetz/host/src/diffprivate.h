#ifndef DIFF_TA_H
#define DIFF_TA_H

void diff_private_func(float *input, int len_input);

#endif

#ifndef DIFF_TA_H
#define DIFF_TA_H

void *diff_private_SGD(float *input, int len_input);

#endif
